package com.example.textbookstore.fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SearchView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.textbookstore.R
import android.widget.TextView
import com.example.textbookstore.activities.DetailActivity
import com.example.textbookstore.adapters.BookAdapter
import com.example.textbookstore.models.Book
import com.example.textbookstore.utils.DataProvider

private lateinit var recyclerView: RecyclerView
private lateinit var adapter: BookAdapter
private lateinit var searchView: SearchView
private lateinit var tvEmptyState: TextView
class ListingsFragment : Fragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: BookAdapter
    private lateinit var searchView: SearchView

    private var books = mutableListOf<Book>()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        val view = inflater.inflate(R.layout.fragment_listings, container, false)

        recyclerView = view.findViewById(R.id.recycler_books)
        searchView = view.findViewById(R.id.search_books)

        tvEmptyState = view.findViewById(R.id.tvEmptyState)

        books = DataProvider.getSampleBooks().toMutableList()

        adapter = BookAdapter(books) { book ->

            val intent = Intent(requireContext(), DetailActivity::class.java)
            intent.putExtra("book_id", book.id)
            startActivity(intent)
        }

        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = adapter

        setupSearch()

        return view
    }

    private fun setupSearch() {

        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {

            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {

                val filtered = DataProvider.getSampleBooks().filter {

                    it.title.contains(newText ?: "", true) ||
                            it.author.contains(newText ?: "", true) ||
                            it.courseCode.contains(newText ?: "", true)
                }

                adapter.updateList(filtered)

                if (filtered.isEmpty()) {
                    tvEmptyState.visibility = View.VISIBLE
                    recyclerView.visibility = View.GONE
                } else {
                    tvEmptyState.visibility = View.GONE
                    recyclerView.visibility = View.VISIBLE
                }

                return true
            }
        })
    }

    private lateinit var tvEmptyState: TextView
}