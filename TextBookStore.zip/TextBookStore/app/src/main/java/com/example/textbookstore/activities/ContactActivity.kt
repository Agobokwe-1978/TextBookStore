package com.example.textbookstore.activities

import android.os.Bundle
import android.util.Patterns
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.textbookstore.R

class ContactActivity : AppCompatActivity() {

    private lateinit var etName: EditText
    private lateinit var etEmail: EditText
    private lateinit var etMessage: EditText
    private lateinit var btnSend: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_contact)

        etName = findViewById(R.id.etName)
        etEmail = findViewById(R.id.etEmail)
        etMessage = findViewById(R.id.etMessage)
        btnSend = findViewById(R.id.btnSend)

        btnSend.setOnClickListener {
            validateAndSend()
        }
    }

    private fun validateAndSend() {

        val name = etName.text.toString().trim()
        val email = etEmail.text.toString().trim()
        val message = etMessage.text.toString().trim()

        when {
            name.isEmpty() -> {
                etName.error = "Please enter your name"
                etName.requestFocus()
            }

            email.isEmpty() -> {
                etEmail.error = "Please enter your email"
                etEmail.requestFocus()
            }

            !Patterns.EMAIL_ADDRESS.matcher(email).matches() -> {
                etEmail.error = "Invalid email address"
                etEmail.requestFocus()
            }

            message.isEmpty() -> {
                etMessage.error = "Please enter a message"
                etMessage.requestFocus()
            }

            else -> {
                Toast.makeText(
                    this,
                    "Enquiry sent successfully!",
                    Toast.LENGTH_LONG
                ).show()

                etName.text.clear()
                etEmail.text.clear()
                etMessage.text.clear()
            }
        }
    }
}